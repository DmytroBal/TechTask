import UIKit

protocol MobileStorage{
    func getAll() -> Set<Mobile>
    func findBylmei(_ imei: String) -> Mobile?
    func save(_ mobile: Mobile) throws -> Mobile
    func delete( product: Mobile) throws
    func exists(_ product: Mobile) -> Bool
}

struct Mobile: Hashable {
    let imei: String
    let model: String
}

enum PossibleErrors: Error {
    case notInStock
    case sameInStock
}

class MobileDevices: MobileStorage {
    
    
    private var mobiles: Set<Mobile> = []
    
    func getAll() -> Set<Mobile> {
        return mobiles
    }
    
    func findBylmei(_ imei: String) -> Mobile? {
        var mobile: Mobile?
        
        for phone in mobiles {
            if phone.imei == imei {
                mobile = phone
            } else {
              print("Phone with this imei does not exist")
            }
        }
        return mobile
    }
    
    func exists(_ product: Mobile) -> Bool {
        
        var isExists = false
        
        if mobiles.contains(product){
            isExists = true
        } else {
            isExists = false
        }
        return isExists
    }

    
    func delete(product: Mobile) throws {
        
        if mobiles.contains(product) {
            mobiles.remove(product)
        } else {
            throw PossibleErrors.notInStock
        }
    }

    func save(_ mobile: Mobile) throws -> Mobile {

        if mobiles.contains(mobile) {
            throw PossibleErrors.sameInStock
            } else {
                mobiles.insert(mobile)
            }
        return mobile
        }
    }



let mobileDevices = MobileDevices()

let iPhone = Mobile(imei: "760293481823749", model: "11Pro")
let sumsung = Mobile(imei: "194729384756102", model: "A7")


try? mobileDevices.save(sumsung)
try? mobileDevices.save(iPhone)
try? mobileDevices.save(sumsung)

mobileDevices.getAll()

mobileDevices.exists(sumsung)
try? mobileDevices.delete(product: sumsung)
mobileDevices.exists(sumsung)

mobileDevices.findBylmei("760293481823749")
mobileDevices.findBylmei("194729384756102")
